(() =>{let mod = new Mod('Scarlettcheer');
mod.name = 'Scarlettcheer';
mod.loadImage('CheerleaderUniformScarlett', 'assets/CheerleaderUniformScarlett.png');
mod.loadImage('Scarlett-Clothes-CheerleaderUniformScarlett', 'assets/Scarlett-Clothes-CheerleaderUniformScarlett.png');


mod.init = () => {
mod.clothes.add(new Clothes('CheerleaderUniformScarlett', 'Scarlett', false)).setName('Cheerleader Uniform').setDescription('A uniform for a leader').setLevel(15).setStat({"Throat":0,"Tits":2,"Pussy":3,"Anal":0}).setCost(200).setShop(true).setVisible(true);

};})();